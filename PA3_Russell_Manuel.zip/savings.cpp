#include "savings.h"

Savings::Savings()
{

}

void Savings::set_dailyInterest()
{
	
	double interest = (get_balance()*0.06) / 30;
	cout << "Interest gained: $" << interest <<endl;
	
	savingsBalance = get_balance();
	
	savingsBalance += interest;

	cout << "Net balance of savings is: $" << savingsBalance <<endl;

}