#ifndef SAVINGS_H
#define SAVINGS_H

#include "account.h"

class Savings : public Account
{
public:
	double savingsBalance = 0;
	Savings();
	void set_dailyInterest();

};


#endif