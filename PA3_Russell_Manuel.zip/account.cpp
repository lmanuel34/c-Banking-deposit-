#include "account.h"


Account::Account()
{
	balance = 500;
	withdraw = 0;
	deposit = 0;
	counter++;
}

Account:: ~Account()
{
	//cout << "this is the deconstructor " << endl;
}

void Account::set_balance(double b)
{
	balance = b;
	
}

void Account::set_deposit(double amount)
{
	
	balance+=amount;
	cout << "deposited: $" << amount << endl;;
	cout << "balance after deposit: $" << balance << endl;
	
}

void Account::set_withdraw(double amount)
{
	
	if (amount> get_balance())
	{
		cout << "insufficent funds cannot make a withdraw" <<endl;
		
		return;
	}
	else
	{
		balance -= amount;
		cout << "Withdrawn: $" << amount << endl;
		cout << "Net Balance after withdraw: $" << get_balance() << endl;
	}
}

double Account::get_balance()
{
	return balance;
}

double Account::get_deposit()
{
	return deposit;
}

double Account::get_withdraw()
{
	return withdraw;
}