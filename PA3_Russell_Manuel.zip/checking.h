#ifndef CHECKING_H
#define CHECKING_H

#include "account.h"

class Checking: public Account
{
public:
	double checkingBalance = 0;
	double interest=0;
	Checking();
	void set_monthlyInterest();
	double get_interest();
	double get_checkingBal();

};

#endif
