#ifndef ACCOUNT_H
#define ACCOUNT_H

#include <iostream>


using namespace std;

class Account
{
private:
	
	double balance;
	double deposit;
	double withdraw;
	
public:
	static int counter;
	Account();
	~Account();
	void set_balance(double);
	void set_deposit(double);
	void set_withdraw(double);
	double get_balance();
	double get_deposit();
	double get_withdraw();


};

#endif
