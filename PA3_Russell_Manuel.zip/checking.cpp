#include "checking.h"

Checking::Checking()
{

}

void Checking::set_monthlyInterest()
{
	
	if (get_balance() > 1000)
	{
		double over1000 = get_balance();
		interest = (0.03 * over1000) / 30;
		cout << "Interest earned: $" << interest << endl;
		checkingBalance = get_balance();
		checkingBalance += interest;
		
		
	}
	else
	{
		cout << "insuffcient funds to garner interest" << endl;
		cout << "net balance is: $" << get_balance()<<endl;
	}
}

double Checking::get_checkingBal()
{
	return checkingBalance;
}

double Checking::get_interest()
{
	return interest;
}